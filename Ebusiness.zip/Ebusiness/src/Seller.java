import java.util.Hashtable;

import jade.core.Agent;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.wrapper.AgentController;



public class Seller extends Agent{

		
	protected void setup() {
	
		AgentController anotherName=null;
	  //  anotherName = createNewAgent("Agent1", "jade.Agent1", null);
	   // anotherName.start(); 
		
		
	}





	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
		this.setup();
	}
	
	
	
	
	
}
